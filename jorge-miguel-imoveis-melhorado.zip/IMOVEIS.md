# Catálogo de imóveis

Os imóveis ficam em `client/public/properties.json` (lista vazia `[]` por padrão). O site lê esse arquivo a cada visita:
**incluir, editar ou tirar um imóvel do ar não exige novo build do código**, só publicar o arquivo.

## Regras de exibição
| `status` | Catálogo | Página do imóvel |
|---|---|---|
| `publicado` | aparece | sim |
| `em-breve` | aparece com selo "Em breve" | sim |
| `vendido` | some da lista | continua abrindo, com aviso "vendido" e CTA para opções parecidas |
| `rascunho` | não aparece | não abre |

`authorized` precisa ser `true`; com `false` o imóvel nunca aparece, qualquer que seja o status. Use só com anúncios e fotos que você tem autorização para publicar.

## Campos
Obrigatórios: `id` (letras, números, `-`, `_`; vai na URL), `title`, `city`, `regionSlug` (`balneario-picarras`, `penha`, `barra-velha`), `neighborhood`, `type`, `status`, `authorized`.
Opcionais: `purpose` (Morar, Investir, Alto padrão, Renda, Na planta), `bedrooms`, `suites`, `parking`, `area`, `price`, `description`, `image`, `gallery` (lista de URLs), `features` (lista), `developer`, `delivery`, `updatedAt` (AAAA-MM-DD, define a ordem "mais recentes").

Modelo completo em `scripts/properties.example.json`. Antes de publicar: `pnpm check:data`.

## Atualização automática
Qualquer rotina (planilha, CRM, GitHub Action) que gere esse JSON mantém o site atualizado. Só automatize a partir de fontes cujo uso você tenha autorização.

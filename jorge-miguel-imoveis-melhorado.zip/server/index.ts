import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.disable("x-powered-by");

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    next();
  });

  app.get("/healthz", (_req, res) => res.json({ ok: true }));

  // Arquivos com hash no nome (Vite) podem ficar em cache por 1 ano.
  app.use("/assets", express.static(path.join(staticPath, "assets"), { maxAge: "1y", immutable: true }));

  // HTML e o catálogo nunca ficam em cache: imóvel novo ou vendido aparece/some na hora.
  app.use(
    express.static(staticPath, {
      maxAge: "1h",
      setHeaders(res, file) {
        if (file.endsWith(".html") || file.endsWith("properties.json")) res.setHeader("Cache-Control", "no-cache");
      },
    })
  );

  // Handle client-side routing - serve index.html for page routes.
  // Pedidos de arquivos inexistentes (.png, .js, .json...) recebem 404 de verdade, e não o HTML.
  app.get("*", (req, res) => {
    if (path.extname(req.path)) return res.status(404).type("text/plain").send("Not found");
    res.setHeader("Cache-Control", "no-cache");
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);

/* Valida o catálogo antes de publicar:  pnpm check:data  (ou: pnpm check:data caminho/outro.json) */
import fs from "node:fs";
import path from "node:path";
import { propertySchema } from "../client/src/lib/propertySchema";

const file = path.resolve(process.argv[2] ?? "client/public/properties.json");
let raw: unknown;
try {
  raw = JSON.parse(fs.readFileSync(file, "utf-8"));
} catch (error) {
  console.error(`✖ Não consegui ler ${file}: ${(error as Error).message}`);
  process.exit(1);
}
if (!Array.isArray(raw)) {
  console.error("✖ O arquivo precisa ser uma lista ([ ... ]) de imóveis.");
  process.exit(1);
}

let errors = 0;
const warnings: string[] = [];
const seen = new Set<string>();

raw.forEach((item, index) => {
  const label = `#${index + 1} (${(item as { id?: string })?.id ?? "sem id"})`;
  const parsed = propertySchema.safeParse(item);
  if (!parsed.success) {
    errors++;
    parsed.error.issues.forEach((issue) => console.error(`✖ ${label}: ${issue.path.join(".") || "item"} — ${issue.message}`));
    return;
  }
  const p = parsed.data;
  if (seen.has(p.id)) { errors++; console.error(`✖ ${label}: código duplicado "${p.id}"`); }
  seen.add(p.id);
  if (p.authorized && p.status !== "rascunho") {
    if (!p.image) warnings.push(`${label}: publicado sem foto de capa`);
    if (!p.price && p.status !== "vendido") warnings.push(`${label}: sem preço (aparece como "Consulte as condições")`);
    if (!p.description) warnings.push(`${label}: sem descrição própria`);
  }
  if (!p.authorized && p.status !== "rascunho") warnings.push(`${label}: status "${p.status}", mas authorized=false — não aparece no site`);
});

warnings.forEach((w) => console.warn(`⚠ ${w}`));
console.log(`${errors ? "✖" : "✔"} ${raw.length} imóvel(is) lido(s), ${errors} erro(s), ${warnings.length} aviso(s).`);
process.exit(errors ? 1 : 0);

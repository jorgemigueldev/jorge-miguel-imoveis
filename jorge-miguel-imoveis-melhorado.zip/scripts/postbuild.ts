/*
 * Roda depois do vite build:
 *  - sitemap.xml + robots.txt (precisa de SITE_URL, ex.: SITE_URL=https://www.seudominio.com.br)
 *  - 404.html (cópia do index.html, para hospedagens como GitHub Pages)
 */
import fs from "node:fs";
import path from "node:path";
import { propertySchema } from "../client/src/lib/propertySchema";
import { isListed, regions, slugify } from "../client/src/lib/properties";

const out = path.resolve("dist/public");
fs.copyFileSync(path.join(out, "index.html"), path.join(out, "404.html"));

const site = (process.env.SITE_URL ?? "").replace(/\/+$/, "");
if (!site) {
  console.warn("⚠ SITE_URL não definido: sitemap.xml não foi gerado (defina SITE_URL no build para o Google indexar tudo).");
  process.exit(0);
}

const props = (() => {
  try {
    const raw = JSON.parse(fs.readFileSync(path.join(out, "properties.json"), "utf-8"));
    return (Array.isArray(raw) ? raw : []).flatMap((item) => { const r = propertySchema.safeParse(item); return r.success ? [r.data] : []; });
  } catch { return []; }
})();

const paths = [
  "/", "/imoveis", "/cidades", "/sobre", "/contato", "/privacidade",
  ...regions.flatMap((r) => [`/cidades/${r.slug}`, ...r.neighborhoods.map((n) => `/bairros/${r.slug}/${slugify(n)}`)]),
  ...props.filter(isListed).map((p) => `/imovel/${p.id}`),
];
const today = new Date().toISOString().slice(0, 10);
fs.writeFileSync(path.join(out, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${paths.map((p) => `  <url><loc>${site}${p}</loc><lastmod>${today}</lastmod></url>`).join("\n")}\n</urlset>\n`);
fs.writeFileSync(path.join(out, "robots.txt"), `User-agent: *\nAllow: /\n\nSitemap: ${site}/sitemap.xml\n`);
console.log(`✔ sitemap.xml com ${paths.length} URLs`);

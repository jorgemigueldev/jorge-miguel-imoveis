# Jorge Miguel Imóveis — site

React 19 + Vite + Tailwind 4 + wouter, com servidor Express opcional.

## Comandos
| Comando | O que faz |
|---|---|
| `pnpm install` | instala dependências |
| `pnpm dev` | servidor de desenvolvimento |
| `pnpm check` / `pnpm test` | tipos e testes |
| `pnpm check:data` | valida `client/public/properties.json` |
| `pnpm build` | build + servidor Express + sitemap (`pnpm start` roda) |
| `pnpm build:static` | só arquivos estáticos em `dist/public` (Vercel, Netlify, Cloudflare Pages) |

## Publicar fora da Manus
1. Coloque as 7 imagens do site em `client/public/images/` (mesmos nomes de `client/src/lib/assets.ts`).
2. Copie `.env.example` para `.env`: `VITE_ASSET_BASE=/images` e `SITE_URL=https://seudominio`.
3. Vercel: importe o repositório (`vercel.json` já configura). Netlify/Cloudflare: build `pnpm build:static`, saída `dist/public`.
Obs.: o site espera estar na raiz do domínio (não em subpasta, como GitHub Pages de projeto).

## Catálogo
Veja `IMOVEIS.md`. Resumo: edite `client/public/properties.json`, rode `pnpm check:data` e publique. Não precisa mexer no código.

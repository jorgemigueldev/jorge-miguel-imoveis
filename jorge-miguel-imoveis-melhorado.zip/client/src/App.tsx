/* Design: Maré Editorial — roteamento público para portal imobiliário, com páginas locais e de conversão sem perder a linguagem premium. */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ScrollToTop } from "./components/PortalChrome";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Catalog from "./pages/Catalog";
import CityIndex from "./pages/CityIndex";
import CityPage from "./pages/CityPage";
import NotFound from "./pages/NotFound";
import { AboutPage, ContactPage, NeighborhoodPage, PrivacyPage, PropertyPage } from "./pages/PortalPages";

function AppRoutes() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/imoveis" component={Catalog} />
      <Route path="/imovel/:id" component={PropertyPage} />
      <Route path="/cidades" component={CityIndex} />
      <Route path="/cidades/:slug" component={CityPage} />
      <Route path="/bairros/:city/:neighborhood" component={NeighborhoodPage} />
      <Route path="/sobre" component={AboutPage} />
      <Route path="/contato" component={ContactPage} />
      <Route path="/privacidade" component={PrivacyPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <a href="#conteudo" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded focus:bg-white focus:px-4 focus:py-2">Ir para o conteúdo</a>
          <Toaster />
          <ScrollToTop />
          <AppRoutes />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

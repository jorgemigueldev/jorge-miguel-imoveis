/*
 * Imagens do site em um único lugar.
 * Hoje os arquivos vêm do armazenamento da Manus (/manus-storage). Para hospedar fora dela:
 *   1) baixe as 7 imagens e coloque em client/public/images/ (com os mesmos nomes);
 *   2) defina VITE_ASSET_BASE=/images no arquivo .env.
 */
const base = ((import.meta.env?.VITE_ASSET_BASE as string | undefined) || "/manus-storage").replace(/\/+$/, "");

export const assets = {
  logo: `${base}/jorge-miguel-logo-transparent_70e3e9c7.png`,
  portrait: `${base}/jorge-miguel-profissional_2d65a9ad.jpg`,
  heroSea: `${base}/jorge-hero-mar-tratado_92929554.png`,
  ogImage: `${base}/jorge-hero-litoral_92192dd5.jpg`,
  picarras: `${base}/jorge-picarras-regional-tratada_21a0b610.png`,
  penha: `${base}/jorge-penha-regional-tratada_2ce56701.png`,
  barraVelha: `${base}/jorge-barra-velha-regional-tratada_b4651cf5.png`,
} as const;

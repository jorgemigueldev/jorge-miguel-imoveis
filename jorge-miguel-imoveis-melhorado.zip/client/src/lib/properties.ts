/* Design: Maré Editorial — dados separados da interface para facilitar catálogo, SEO e campanhas sem editar HTML/JSX. */
import { assets } from "./assets";
import type { z } from "zod";
import type { propertySchema } from "./propertySchema";

export type Purpose = "Morar" | "Investir" | "Alto padrão" | "Renda" | "Na planta";
export type RegionSlug = "barra-velha" | "balneario-picarras" | "penha";
export type PropertyStatus = "publicado" | "em-breve" | "vendido" | "rascunho";
export type Property = z.infer<typeof propertySchema>;

export type Region = {
  slug: RegionSlug;
  name: string;
  subtitle: string;
  kicker: string;
  image: string;
  neighborhoods: string[];
  description: string;
};

export const regions: Region[] = [
  { slug: "balneario-picarras", name: "Balneário Piçarras", subtitle: "O mar como endereço", kicker: "100% Selo Bandeira Azul · Alto padrão", image: assets.picarras, neighborhoods: ["Itacolomi", "Centro", "Nossa Senhora da Paz", "Santo Antônio"], description: "Praias extensas, novos empreendimentos e um mercado em transformação." },
  { slug: "penha", name: "Penha", subtitle: "Entre natureza e movimento", kicker: "Cidade do Beto Carrero World", image: assets.penha, neighborhoods: ["Armação", "Praia Alegre", "Gravatá", "Centro"], description: "Um território de experiências, moradia e oportunidades próximas ao mar." },
  { slug: "barra-velha", name: "Barra Velha", subtitle: "Tempo para viver melhor", kicker: "Tempo para viver melhor", image: assets.barraVelha, neighborhoods: ["Itajubá", "Tabuleiro", "Centro", "São Cristóvão"], description: "Baías, bairros em expansão e uma nova forma de estar no litoral." },
];

export const purposes: Purpose[] = ["Morar", "Investir", "Alto padrão", "Renda", "Na planta"];

/* ---------- utilitários ---------- */

/** "Nossa Senhora da Paz" -> "nossa-senhora-da-paz" (sem acentos, seguro para URL) */
export function slugify(text: string) {
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

export function getRegion(slug?: string) {
  return regions.find((item) => item.slug === slug);
}

/** Resolve o nome real do bairro (com acento) a partir do slug da URL. */
export function getNeighborhood(regionSlug: string | undefined, neighborhoodSlug: string | undefined) {
  const region = getRegion(regionSlug);
  if (!region || !neighborhoodSlug) return undefined;
  const wanted = slugify(decodeURIComponent(neighborhoodSlug));
  const name = region.neighborhoods.find((item) => slugify(item) === wanted);
  return name ? { region, name } : undefined;
}

export function formatPrice(price?: number) {
  if (!price) return "Consulte as condições";
  return price.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
}

/* ---------- visibilidade ---------- */

/** Aparece nas listagens do catálogo (nunca rascunho, nunca sem autorização, nunca vendido). */
export const isListed = (p: Property) => p.authorized && (p.status === "publicado" || p.status === "em-breve");
/** Pode abrir a página individual (vendido continua acessível para não gerar link quebrado). */
export const isViewable = (p: Property) => p.authorized && p.status !== "rascunho";

/* ---------- filtros e ordenação ---------- */

/* Faixas alinhadas ao posicionamento premium: a base de corte do portal é R$ 1 milhão. */
export const budgetRanges = [
  { label: "Até R$ 1 milhão", min: 0, max: 1_000_000 },
  { label: "R$ 1 a 2 milhões", min: 1_000_000, max: 2_000_000 },
  { label: "R$ 2 a 3 milhões", min: 2_000_000, max: 3_000_000 },
  { label: "Acima de R$ 3 milhões", min: 3_000_000, max: Infinity },
] as const;

export const sortOptions = [
  { value: "recentes", label: "Mais recentes" },
  { value: "menor-preco", label: "Menor preço" },
  { value: "maior-preco", label: "Maior preço" },
] as const;
export type SortValue = (typeof sortOptions)[number]["value"];

export type Filters = { query: string; region: string; purpose: string; budget: string; sort: SortValue };
export const ALL_REGIONS = "Todas as regiões";
export const ALL_PURPOSES = "Todas as finalidades";
export const ALL_BUDGETS = "Todas as faixas";

export const defaultFilters: Filters = { query: "", region: ALL_REGIONS, purpose: ALL_PURPOSES, budget: ALL_BUDGETS, sort: "recentes" };

const normalize = (text: string) => text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export function filterProperties(list: Property[], filters: Filters) {
  const q = normalize(filters.query.trim());
  const range = budgetRanges.find((item) => item.label === filters.budget);
  const result = list.filter((p) => {
    if (!isListed(p)) return false;
    // A busca ignora acentos: "picarras" encontra "Piçarras".
    if (q && !normalize(`${p.title} ${p.city} ${p.neighborhood} ${p.type} ${p.developer ?? ""}`).includes(q)) return false;
    if (filters.region !== ALL_REGIONS && p.city !== filters.region) return false;
    if (filters.purpose !== ALL_PURPOSES && !p.purpose.includes(filters.purpose as Purpose)) return false;
    // Imóvel sem preço não entra em faixa de valor (antes ele era tratado como "até R$ 500 mil").
    if (range && !(p.price && p.price > range.min && p.price <= range.max)) return false;
    return true;
  });
  return sortProperties(result, filters.sort);
}

export function sortProperties(list: Property[], sort: SortValue) {
  const copy = [...list];
  if (sort === "menor-preco") return copy.sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
  if (sort === "maior-preco") return copy.sort((a, b) => (b.price ?? -Infinity) - (a.price ?? -Infinity));
  return copy.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}

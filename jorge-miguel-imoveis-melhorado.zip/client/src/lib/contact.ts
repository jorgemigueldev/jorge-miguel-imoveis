/* Contato centralizado: antes o número e as mensagens estavam repetidos em 8 arquivos. */
export const WHATSAPP_NUMBER = "5547984863952";
export const WHATSAPP_DISPLAY = "(47) 98486-3952";
export const CRECI = "CRECI 71144 F";
export const INSTAGRAM_HANDLE = "@jorgemiguelimoveis";
export const INSTAGRAM_URL = "https://instagram.com/jorgemiguelimoveis";
export const YOUTUBE_URL = "https://www.youtube.com/@jorgemiguelimoveissc";

export const DEFAULT_MESSAGE = "Olá, Jorge! Quero conhecer as oportunidades do Litoral Norte SC.";

export function whatsappLink(message: string = DEFAULT_MESSAGE) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

/** Envia evento ao Umami (se configurado). Não faz nada caso o analytics não esteja ativo. */
export function track(event: string, data?: Record<string, string | number>) {
  try {
    (window as unknown as { umami?: { track: (e: string, d?: unknown) => void } }).umami?.track(event, data);
  } catch {
    /* analytics nunca deve quebrar o site */
  }
}

/** Máscara de telefone brasileiro: (47) 99999-9999 */
export function formatPhone(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  if (digits.length <= 2) return digits ? `(${digits}` : "";
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export function isValidPhone(value: string) {
  const digits = value.replace(/\D/g, "");
  return digits.length === 10 || (digits.length === 11 && digits[2] === "9");
}

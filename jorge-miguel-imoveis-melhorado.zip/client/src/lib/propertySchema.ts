import { z } from "zod";

export const purposeValues = ["Morar", "Investir", "Alto padrão", "Renda", "Na planta"] as const;
export const regionValues = ["barra-velha", "balneario-picarras", "penha"] as const;
export const statusValues = ["publicado", "em-breve", "vendido", "rascunho"] as const;

/** Formato de cada imóvel em client/public/properties.json */
export const propertySchema = z.object({
  id: z.string().regex(/^[A-Za-z0-9_-]+$/, "use só letras, números, - ou _ (o código vai na URL)"),
  title: z.string().min(1),
  city: z.string().min(1),
  regionSlug: z.enum(regionValues),
  neighborhood: z.string().min(1),
  purpose: z.array(z.enum(purposeValues)).default([]),
  type: z.string().min(1),
  bedrooms: z.number().int().nonnegative().optional(),
  suites: z.number().int().nonnegative().optional(),
  parking: z.number().int().nonnegative().optional(),
  area: z.number().positive().optional(),
  price: z.number().positive().optional(),
  status: z.enum(statusValues),
  description: z.string().optional(),
  image: z.string().optional(),
  gallery: z.array(z.string()).optional(),
  features: z.array(z.string()).optional(),
  developer: z.string().optional(),
  delivery: z.string().optional(),
  updatedAt: z.string().optional(),
  authorized: z.boolean(),
});

export const propertiesFileSchema = z.array(propertySchema);

import { describe, expect, it } from "vitest";
import { ALL_BUDGETS, ALL_PURPOSES, ALL_REGIONS, defaultFilters, filterProperties, getNeighborhood, isListed, isViewable, slugify, type Property } from "./properties";
import { formatPhone, isValidPhone, whatsappLink } from "./contact";

const base: Property = { id: "A1", title: "Residencial Mar", city: "Balneário Piçarras", regionSlug: "balneario-picarras", neighborhood: "Itacolomi", purpose: ["Alto padrão"], type: "Apartamento", price: 2_500_000, status: "publicado", authorized: true, updatedAt: "2026-10-01" };
const make = (patch: Partial<Property>): Property => ({ ...base, ...patch });

describe("visibilidade", () => {
  it("só lista imóveis autorizados, publicados ou em breve", () => {
    expect(isListed(base)).toBe(true);
    expect(isListed(make({ status: "em-breve" }))).toBe(true);
    expect(isListed(make({ authorized: false }))).toBe(false);
    expect(isListed(make({ status: "rascunho" }))).toBe(false);
    expect(isListed(make({ status: "vendido" }))).toBe(false);
  });
  it("vendido continua com página própria; rascunho e não autorizado, não", () => {
    expect(isViewable(make({ status: "vendido" }))).toBe(true);
    expect(isViewable(make({ status: "rascunho" }))).toBe(false);
    expect(isViewable(make({ authorized: false }))).toBe(false);
  });
});

describe("filtros", () => {
  const list = [base, make({ id: "A2", title: "Casa Penha", city: "Penha", regionSlug: "penha", neighborhood: "Armação", price: 800_000, purpose: ["Morar"] }), make({ id: "A3", price: undefined })];
  it("busca ignora acentos", () => {
    expect(filterProperties(list, { ...defaultFilters, query: "picarras" }).map((p) => p.id)).toEqual(expect.arrayContaining(["A1", "A3"]));
    expect(filterProperties(list, { ...defaultFilters, query: "armacao" }).map((p) => p.id)).toEqual(["A2"]);
  });
  it("faixa de valor exclui imóvel sem preço", () => {
    const ids = filterProperties(list, { ...defaultFilters, budget: "Até R$ 1 milhão" }).map((p) => p.id);
    expect(ids).toEqual(["A2"]);
  });
  it("combina região, finalidade e ordenação por preço", () => {
    expect(filterProperties(list, { ...defaultFilters, region: "Penha", purpose: "Morar" })).toHaveLength(1);
    const sorted = filterProperties(list, { query: "", region: ALL_REGIONS, purpose: ALL_PURPOSES, budget: ALL_BUDGETS, sort: "menor-preco" });
    expect(sorted[0].id).toBe("A2");
  });
});

describe("rotas e slugs", () => {
  it("slugify remove acentos", () => expect(slugify("Nossa Senhora da Paz")).toBe("nossa-senhora-da-paz"));
  it("resolve bairro com acento a partir do slug", () => {
    expect(getNeighborhood("barra-velha", "itajuba")?.name).toBe("Itajubá");
    expect(getNeighborhood("barra-velha", "inexistente")).toBeUndefined();
  });
});

describe("contato", () => {
  it("aplica máscara de telefone", () => {
    expect(formatPhone("47984863952")).toBe("(47) 98486-3952");
    expect(formatPhone("4733334444")).toBe("(47) 3333-4444");
  });
  it("valida telefone", () => {
    expect(isValidPhone("(47) 98486-3952")).toBe(true);
    expect(isValidPhone("(47) 8486-395")).toBe(false);
  });
  it("gera link do WhatsApp com a mensagem codificada", () => expect(whatsappLink("Olá!")).toContain("text=Ol%C3%A1!"));
});

import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { SmartImage } from "@/components/SmartImage";
import { cn } from "@/lib/utils";

/** Galeria com miniaturas, botões e setas do teclado. Funciona com 1 ou N fotos. */
export function PropertyGallery({ images, title }: { images: string[]; title: string }) {
  const [index, setIndex] = useState(0);
  const count = images.length;
  const go = useCallback((step: number) => setIndex((i) => (i + step + count) % count), [count]);

  useEffect(() => setIndex(0), [images]);

  if (!count) return <div role="img" aria-label={title} className="aspect-[4/3] bg-[#dfe5df]" />;

  return (
    <div onKeyDown={(e) => { if (e.key === "ArrowRight") go(1); if (e.key === "ArrowLeft") go(-1); }}>
      <div className="relative aspect-[4/3] overflow-hidden bg-[#dfe5df]">
        <SmartImage key={images[index]} src={images[index]} alt={`${title} — foto ${index + 1} de ${count}`} loading="eager" className="h-full w-full object-cover" />
        {count > 1 && (
          <>
            <button type="button" onClick={() => go(-1)} aria-label="Foto anterior" className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-3 text-[#102f3d] shadow transition hover:bg-white"><ChevronLeft className="h-5 w-5" /></button>
            <button type="button" onClick={() => go(1)} aria-label="Próxima foto" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-3 text-[#102f3d] shadow transition hover:bg-white"><ChevronRight className="h-5 w-5" /></button>
            <span className="absolute bottom-3 right-3 rounded-full bg-[#102f3d]/80 px-3 py-1 text-[11px] text-white">{index + 1} / {count}</span>
          </>
        )}
      </div>
      {count > 1 && (
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {images.map((src, i) => (
            <button key={src + i} type="button" onClick={() => setIndex(i)} aria-label={`Ver foto ${i + 1}`} aria-current={i === index} className={cn("h-16 w-24 shrink-0 overflow-hidden border-2 transition", i === index ? "border-[#6caaa0]" : "border-transparent opacity-70 hover:opacity-100")}>
              <SmartImage src={src} alt="" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* Design: Maré Editorial — chrome editorial com navegação simples, CTA consultivo e consistência entre páginas. */
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowUpRight, Instagram, Menu, MessageCircle, X } from "lucide-react";
import { Logo } from "@/components/Logo";
import { CRECI, INSTAGRAM_HANDLE, INSTAGRAM_URL, track, whatsappLink } from "@/lib/contact";

const nav = [
  { href: "/imoveis", label: "Imóveis" },
  { href: "/cidades", label: "Regiões" },
  { href: "/sobre", label: "Sobre mim" },
  { href: "/contato", label: "Contato" },
];

/** O roteador não rola para o topo sozinho: sem isso, abrir um imóvel mantinha a posição da lista. */
export function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => { if (!window.location.hash) window.scrollTo({ top: 0, left: 0, behavior: "instant" }); }, [location]);
  return null;
}

export function PortalHeader() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  useEffect(() => setOpen(false), [location]);

  return (
    <header className="relative border-b border-[#102f3d]/10 bg-[#f7f5ef] text-[#102f3d]">
      <div className="mx-auto flex max-w-[1320px] items-center justify-between px-5 py-5 lg:px-10">
        <Link href="/" className="flex items-center gap-3" aria-label="Jorge Miguel Imóveis, página inicial">
          <Logo className="h-12 w-40" />
          <span className="hidden text-[9px] uppercase tracking-[0.2em] text-[#648e8c] lg:block">{CRECI} · Curadoria no Litoral Norte de SC</span>
        </Link>
        <nav aria-label="Principal" className="hidden items-center gap-8 text-[10px] uppercase tracking-[0.16em] md:flex">
          {nav.map((item) => <Link key={item.href} href={item.href} className={`hover:text-[#6caaa0] ${location.startsWith(item.href) ? "text-[#6caaa0]" : ""}`}>{item.label}</Link>)}
          <a href={whatsappLink()} onClick={() => track("whatsapp_click", { from: "header" })} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full bg-[#102f3d] px-4 py-3 text-white transition hover:bg-[#214e5a]">WhatsApp <ArrowUpRight className="h-3 w-3 text-[#8ec8ba]" /></a>
        </nav>
        <button type="button" className="md:hidden" onClick={() => setOpen(!open)} aria-label={open ? "Fechar menu" : "Abrir menu"} aria-expanded={open}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <nav aria-label="Menu móvel" className="absolute inset-x-0 top-full z-40 border-t border-[#102f3d]/10 bg-[#f7f5ef] px-5 py-6 shadow-lg md:hidden">
          <div className="flex flex-col gap-5 text-xs uppercase tracking-[0.2em]">
            {nav.map((item) => <Link key={item.href} href={item.href}>{item.label}</Link>)}
            <a href={whatsappLink()} onClick={() => track("whatsapp_click", { from: "menu" })} target="_blank" rel="noreferrer" className="w-fit rounded-full bg-[#102f3d] px-5 py-3 text-white">Falar com Jorge</a>
          </div>
        </nav>
      )}
    </header>
  );
}

export function PortalFooter() {
  return (
    <>
      <footer className="border-t border-[#102f3d]/10 bg-[#f7f5ef] px-5 py-10 text-[#102f3d] lg:px-10">
        <div className="mx-auto flex max-w-[1320px] flex-col justify-between gap-7 md:flex-row md:items-end">
          <div>
            <Logo className="h-12 w-44" />
            <p className="mt-3 text-xs uppercase tracking-[0.18em] text-[#648e8c]">Curadoria no Litoral Norte de SC · {CRECI}</p>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-sm text-[#46636c]">
            <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="flex items-center gap-2"><Instagram className="h-4 w-4" /> {INSTAGRAM_HANDLE}</a>
            <a href={whatsappLink()} onClick={() => track("whatsapp_click", { from: "footer" })} target="_blank" rel="noreferrer" className="flex items-center gap-2 font-semibold"><MessageCircle className="h-4 w-4 text-[#6caaa0]" /> WhatsApp</a>
          </div>
        </div>
        <div className="mx-auto mt-10 flex max-w-[1320px] flex-col justify-between gap-3 border-t border-[#102f3d]/10 pt-5 text-[11px] text-[#648e8c] sm:flex-row">
          <p>© {new Date().getFullYear()} Jorge Miguel Imóveis. Barra Velha · Balneário Piçarras · Penha.</p>
          <p className="flex gap-5"><Link href="/imoveis" className="hover:text-[#102f3d]">Imóveis</Link><Link href="/cidades" className="hover:text-[#102f3d]">Regiões</Link><Link href="/privacidade" className="hover:text-[#102f3d]">Privacidade</Link></p>
        </div>
      </footer>
      <a href={whatsappLink()} onClick={() => track("whatsapp_click", { from: "floating" })} target="_blank" rel="noreferrer" aria-label="Falar com Jorge Miguel pelo WhatsApp" className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#8ec8ba] text-[#102f3d] shadow-xl shadow-[#102f3d]/20 transition hover:scale-105"><MessageCircle className="h-6 w-6" /></a>
    </>
  );
}

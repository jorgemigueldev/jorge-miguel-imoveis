import { useState } from "react";
import { assets } from "@/lib/assets";
import { cn } from "@/lib/utils";

/** Logo da marca. Se o arquivo não carregar, mostra o nome em tipografia editorial (herda a cor do texto ao redor). */
export function Logo({ className }: { className?: string }) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return <span className={cn("flex flex-col justify-center whitespace-nowrap font-display uppercase leading-none tracking-[0.16em]", className)}><span className="text-base">Jorge Miguel</span><span className="mt-1 text-[10px] tracking-[0.5em]">Imóveis</span></span>;
  }
  return <img src={assets.logo} alt="Jorge Miguel Imóveis" onError={() => setFailed(true)} className={cn("object-contain object-left", className)} />;
}

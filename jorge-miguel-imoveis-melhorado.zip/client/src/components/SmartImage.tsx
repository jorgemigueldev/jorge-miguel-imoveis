import { useState, type ImgHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

/** <img> com carregamento preguiçoso e um bloco neutro caso a imagem não exista ou falhe (evita o ícone de imagem quebrada). */
export function SmartImage({ src, alt, className, ...rest }: ImgHTMLAttributes<HTMLImageElement>) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) return <div role="img" aria-label={alt} className={cn("bg-[#dfe5df]", className)} />;
  return <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setFailed(true)} className={className} {...rest} />;
}

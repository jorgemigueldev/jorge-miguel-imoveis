import { useState, type FormEvent } from "react";
import { Link } from "wouter";
import { ArrowUpRight, Check } from "lucide-react";
import { formatPhone, isValidPhone, track, whatsappLink } from "@/lib/contact";
import { regions } from "@/lib/properties";

export const objectives = ["Morar perto do mar", "Investir na planta", "Comprar alto padrão", "Gerar renda com locação"];
export const investmentRanges = ["Até R$ 1 milhão", "R$ 1 a 2 milhões", "R$ 2 a 3 milhões", "Acima de R$ 3 milhões", "Prefiro conversar sobre isso"];

type Props = { defaultRegion?: string; defaultObjective?: string; source?: string };

/*
 * Diagnóstico rápido (fundo escuro). Nada é armazenado pelo site: os dados só montam a mensagem do WhatsApp.
 * Novidade: faixa de investimento — a conversa já chega qualificada (objetivo + cidade + faixa).
 */
export function LeadForm({ defaultRegion = "", defaultObjective = "", source = "site" }: Props) {
  const [form, setForm] = useState({ name: "", phone: "", objective: defaultObjective, region: defaultRegion, budget: "" });
  const [phoneError, setPhoneError] = useState(false);
  const [link, setLink] = useState("");

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!isValidPhone(form.phone)) return setPhoneError(true);
    const where = form.region && form.region !== "Ainda não decidi" ? ` em ${form.region}` : " no Litoral Norte SC";
    const budget = form.budget && !form.budget.startsWith("Prefiro") ? ` Faixa de investimento: ${form.budget.toLowerCase()}.` : "";
    const message = `Olá, Jorge! Sou ${form.name}. Tenho interesse em ${form.objective.toLowerCase()}${where}.${budget} Meu WhatsApp é ${form.phone}.`;
    const url = whatsappLink(message);
    track("lead_submit", { source, objective: form.objective, region: form.region || "n/d", budget: form.budget || "n/d" });
    setLink(url);
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <form onSubmit={submit} noValidate className="border border-white/15 bg-white/[.04] p-6 sm:p-10">
      <div className="grid gap-6 sm:grid-cols-2">
        <label className="field"><span>Como posso chamar você?</span><input required autoComplete="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Seu nome" /></label>
        <label className="field"><span>WhatsApp</span><input required inputMode="tel" autoComplete="tel" value={form.phone} aria-invalid={phoneError} onChange={(e) => { setPhoneError(false); setForm({ ...form, phone: formatPhone(e.target.value) }); }} placeholder="(47) 99999-9999" />{phoneError && <em className="text-xs not-italic text-[#f3b9a8]">Confira o número: DDD + telefone.</em>}</label>
        <label className="field"><span>O que você procura?</span><select required value={form.objective} onChange={(e) => setForm({ ...form, objective: e.target.value })}><option value="">Selecione uma opção</option>{objectives.map((item) => <option key={item}>{item}</option>)}</select></label>
        <label className="field"><span>Região de interesse</span><select required value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })}><option value="">Selecione uma região</option>{regions.map((item) => <option key={item.slug}>{item.name}</option>)}<option>Ainda não decidi</option></select></label>
        <label className="field sm:col-span-2"><span>Faixa de investimento</span><select value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })}><option value="">Selecione (opcional)</option>{investmentRanges.map((item) => <option key={item}>{item}</option>)}</select></label>
      </div>
      <button type="submit" className="mt-8 flex w-full items-center justify-center gap-3 rounded-full bg-[#8ec8ba] px-6 py-4 text-sm font-semibold text-[#102f3d] transition hover:bg-white">
        {link ? <><Check className="h-4 w-4" /> Mensagem preparada no WhatsApp</> : <>Quero receber uma seleção <ArrowUpRight className="h-4 w-4" /></>}
      </button>
      {link && <p className="mt-4 text-center text-xs text-white/60">O WhatsApp não abriu? <a href={link} target="_blank" rel="noreferrer" className="text-[#8ec8ba] underline">Clique aqui</a>.</p>}
      <p className="mt-4 text-center text-[11px] text-white/35">Ao enviar, você será direcionado ao WhatsApp. O site não guarda seus dados. <Link href="/privacidade" className="underline">Privacidade</Link></p>
    </form>
  );
}

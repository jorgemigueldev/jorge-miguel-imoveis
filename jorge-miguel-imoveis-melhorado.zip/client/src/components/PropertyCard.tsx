import { Link } from "wouter";
import { ArrowUpRight, BedDouble, Maximize2 } from "lucide-react";
import { SmartImage } from "@/components/SmartImage";
import { formatPrice, type Property } from "@/lib/properties";

export function PropertyCard({ property }: { property: Property }) {
  const soon = property.status === "em-breve";
  return (
    <article className="group overflow-hidden border border-[#102f3d]/10 bg-white transition hover:shadow-xl hover:shadow-[#102f3d]/10">
      <Link href={`/imovel/${property.id}`} aria-label={`Ver ${property.title}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden bg-[#dfe5df]">
          <SmartImage src={property.image} alt={property.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.03]" />
          {soon && <span className="absolute left-4 top-4 rounded-full bg-[#102f3d] px-3 py-1 text-[10px] uppercase tracking-[0.16em] text-white">Em breve</span>}
        </div>
        <div className="p-6">
          <p className="text-[10px] uppercase tracking-[0.18em] text-[#648e8c]">{property.city} · {property.neighborhood}</p>
          <h3 className="mt-3 font-display text-3xl leading-[1.05]">{property.title}</h3>
          <p className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-[#53707a]">
            <span>{property.type}</span>
            {property.area && <span className="flex items-center gap-1"><Maximize2 className="h-3.5 w-3.5 text-[#6caaa0]" />{property.area} m²</span>}
            {property.bedrooms ? <span className="flex items-center gap-1"><BedDouble className="h-3.5 w-3.5 text-[#6caaa0]" />{property.bedrooms} dorm.</span> : null}
          </p>
          <div className="mt-6 flex items-end justify-between border-t border-[#102f3d]/10 pt-4">
            <p className="font-display text-2xl">{formatPrice(property.price)}</p>
            <span className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-[0.14em]">Ver imóvel <ArrowUpRight className="h-4 w-4 text-[#6caaa0] transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></span>
          </div>
        </div>
      </Link>
    </article>
  );
}

export function PropertyGrid({ properties }: { properties: Property[] }) {
  return <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{properties.map((property) => <PropertyCard key={property.id} property={property} />)}</div>;
}

export function PropertyGridSkeleton() {
  return <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3" aria-busy="true" aria-label="Carregando imóveis">{[0, 1, 2].map((i) => <div key={i} className="animate-pulse border border-[#102f3d]/10 bg-white"><div className="aspect-[4/3] bg-[#dfe5df]" /><div className="space-y-3 p-6"><div className="h-3 w-1/2 bg-[#dfe5df]" /><div className="h-7 w-4/5 bg-[#dfe5df]" /><div className="h-3 w-2/3 bg-[#dfe5df]" /></div></div>)}</div>;
}

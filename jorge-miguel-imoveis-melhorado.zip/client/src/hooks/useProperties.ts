import { useEffect, useState } from "react";
import { propertySchema } from "@/lib/propertySchema";
import type { Property } from "@/lib/properties";

/*
 * O catálogo é lido de /properties.json em tempo de execução.
 * Para incluir, editar ou tirar um imóvel do ar basta atualizar esse arquivo (sem rebuild do site).
 * Imóveis inválidos são ignorados e avisados no console, em vez de derrubar a página.
 */
let cache: Promise<Property[]> | null = null;

function parse(data: unknown): Property[] {
  const raw = Array.isArray(data) ? data : (data as { properties?: unknown[] })?.properties;
  if (!Array.isArray(raw)) return [];
  const valid: Property[] = [];
  raw.forEach((item, index) => {
    const result = propertySchema.safeParse(item);
    if (result.success) valid.push(result.data);
    else console.warn(`[properties.json] item ${index} ignorado:`, result.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; "));
  });
  return valid;
}

export function loadProperties(force = false) {
  if (!cache || force) {
    cache = fetch("/properties.json", { cache: "no-cache" })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json();
      })
      .then(parse)
      .catch((error) => {
        cache = null; // permite nova tentativa na próxima navegação
        throw error;
      });
  }
  return cache;
}

export type PropertiesState = { properties: Property[]; loading: boolean; error: boolean };

export function useProperties(): PropertiesState {
  const [state, setState] = useState<PropertiesState>({ properties: [], loading: true, error: false });
  useEffect(() => {
    let active = true;
    loadProperties()
      .then((properties) => active && setState({ properties, loading: false, error: false }))
      .catch(() => active && setState({ properties: [], loading: false, error: true }));
    return () => {
      active = false;
    };
  }, []);
  return state;
}

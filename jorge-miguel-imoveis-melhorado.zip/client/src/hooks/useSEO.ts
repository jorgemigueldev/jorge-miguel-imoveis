import { useEffect } from "react";
import { assets } from "@/lib/assets";

const SITE = "Jorge Miguel Imóveis";
const DEFAULT_DESCRIPTION = "Jorge Miguel Imóveis — curadoria no Litoral Norte de Santa Catarina, com atuação em Barra Velha, Balneário Piçarras e Penha.";

type SEO = {
  title?: string;
  description?: string;
  image?: string;
  /** Dados estruturados (schema.org) específicos da página. */
  jsonLd?: Record<string, unknown>;
  /** Use em páginas que não devem aparecer no Google. */
  noindex?: boolean;
};

function setMeta(selector: string, attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

const absolute = (url: string) => (url.startsWith("http") ? url : `${window.location.origin}${url}`);

/** Atualiza título, descrição, canonical, Open Graph e JSON-LD a cada página (o site é uma SPA). */
export function useSEO({ title, description = DEFAULT_DESCRIPTION, image = assets.ogImage, jsonLd, noindex }: SEO = {}) {
  const jsonKey = jsonLd ? JSON.stringify(jsonLd) : "";
  useEffect(() => {
    const fullTitle = title ? `${title} | ${SITE}` : `${SITE} | Curadoria no Litoral Norte de SC`;
    const url = `${window.location.origin}${window.location.pathname}`;
    document.title = fullTitle;
    setMeta('meta[name="description"]', "name", "description", description);
    setMeta('meta[property="og:title"]', "property", "og:title", fullTitle);
    setMeta('meta[property="og:description"]', "property", "og:description", description);
    setMeta('meta[property="og:image"]', "property", "og:image", absolute(image));
    setMeta('meta[property="og:url"]', "property", "og:url", url);
    setMeta('meta[name="twitter:card"]', "name", "twitter:card", "summary_large_image");
    setMeta('meta[name="robots"]', "name", "robots", noindex ? "noindex, nofollow" : "index, follow");

    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.rel = "canonical";
      document.head.appendChild(canonical);
    }
    canonical.href = url;

    document.getElementById("page-jsonld")?.remove();
    if (jsonKey) {
      const script = document.createElement("script");
      script.id = "page-jsonld";
      script.type = "application/ld+json";
      script.text = jsonKey;
      document.head.appendChild(script);
    }
    return () => document.getElementById("page-jsonld")?.remove();
  }, [title, description, image, jsonKey, noindex]);
}

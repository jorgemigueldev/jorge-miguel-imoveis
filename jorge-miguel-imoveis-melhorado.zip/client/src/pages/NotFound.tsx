import { useSEO } from "@/hooks/useSEO";
import { EmptyPage } from "@/pages/PortalPages";

/* Página 404 na identidade do site (antes era um modelo genérico em inglês e as rotas inválidas mostravam a Home). */
export default function NotFound() {
  useSEO({ title: "Página não encontrada", noindex: true });
  return <EmptyPage title="Página não encontrada." copy="O endereço pode ter mudado ou o imóvel já foi vendido. Veja os imóveis disponíveis ou fale comigo." />;
}

/* Design: Maré Editorial — páginas locais para SEO e campanhas por cidade, com bairros, imóveis da região e intenção de compra. */
import { Link, useParams } from "wouter";
import { ArrowUpRight, MapPin } from "lucide-react";
import { PortalFooter, PortalHeader } from "@/components/PortalChrome";
import { PropertyGrid, PropertyGridSkeleton } from "@/components/PropertyCard";
import { useProperties } from "@/hooks/useProperties";
import { useSEO } from "@/hooks/useSEO";
import { track, whatsappLink } from "@/lib/contact";
import { getRegion, isListed, slugify } from "@/lib/properties";
import NotFound from "@/pages/NotFound";

export default function CityPage() {
  const { slug } = useParams<{ slug: string }>();
  const region = getRegion(slug);
  const { properties, loading } = useProperties();
  useSEO(region ? { title: `Imóveis em ${region.name}`, description: `${region.description} Bairros, estilo de vida e imóveis selecionados em ${region.name}, Litoral Norte de SC.`, image: region.image } : { title: "Região", noindex: true });

  if (!region) return <NotFound />;
  const here = properties.filter((p) => isListed(p) && p.regionSlug === region.slug);

  return (
    <div className="min-h-screen bg-[#f7f5ef] text-[#102f3d]">
      <PortalHeader />
      <main id="conteudo">
        <section className="relative overflow-hidden bg-[#102f3d] px-5 py-24 text-white lg:px-10 lg:py-32">
          <img src={region.image} alt="" onError={(e) => (e.currentTarget.style.display = "none")} className="absolute inset-0 h-full w-full object-cover opacity-30" />
          <div className="relative mx-auto max-w-[1320px]">
            <p className="eyebrow text-[#8ec8ba]">Curadoria local · Litoral Norte de SC</p>
            <h1 className="mt-5 max-w-3xl font-display text-6xl leading-[.9] sm:text-7xl">{region.name}</h1>
            <p className="mt-7 max-w-lg text-lg leading-relaxed text-white/75">{region.description} Encontre aqui uma leitura mais clara de bairros, estilos de vida e oportunidades.</p>
          </div>
        </section>

        <section className="px-5 pt-20 lg:px-10">
          <div className="mx-auto max-w-[1320px]">
            <div className="mb-8 flex items-end justify-between"><h2 className="font-display text-4xl">Imóveis em {region.name}</h2>{here.length > 0 && <Link href={`/imoveis?cidade=${region.slug}`} className="text-xs font-semibold uppercase tracking-[0.14em]">Filtrar no catálogo →</Link>}</div>
            {loading ? <PropertyGridSkeleton /> : here.length ? <PropertyGrid properties={here} /> : <p className="border border-dashed border-[#102f3d]/20 bg-[#edf0eb] p-8 text-[#53707a]">Ainda não há imóveis publicados aqui. Peça uma seleção personalizada de {region.name} no WhatsApp.</p>}
          </div>
        </section>

        <section className="px-5 py-20 lg:px-10 lg:py-28">
          <div className="mx-auto max-w-[1320px] grid gap-16 lg:grid-cols-[.8fr_1.2fr]">
            <div>
              <p className="eyebrow text-[#648e8c]">Escolha o seu recorte</p>
              <h2 className="mt-4 font-display text-5xl leading-[.95]">Onde faz sentido procurar em {region.name}?</h2>
              <p className="mt-6 text-base leading-relaxed text-[#53707a]">Comece pelo bairro, depois refine por finalidade e faixa de investimento.</p>
              <Link href={`/imoveis?cidade=${region.slug}`} className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#102f3d] px-6 py-4 text-sm text-white">Ver catálogo <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></Link>
            </div>
            <div>
              <p className="eyebrow text-[#648e8c]">Bairros mapeados</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">{region.neighborhoods.map((n) => <Link key={n} href={`/bairros/${region.slug}/${slugify(n)}`} className="group flex items-center justify-between border-b border-[#102f3d]/15 py-5 text-lg text-[#46636c] transition hover:text-[#102f3d]"><span className="flex items-center gap-3"><MapPin className="h-4 w-4 text-[#6caaa0]" />{n}</span><ArrowUpRight className="h-4 w-4 opacity-40 transition group-hover:-translate-y-1 group-hover:translate-x-1" /></Link>)}</div>
            </div>
          </div>
        </section>

        <section className="bg-[#e7e4db] px-5 py-20 lg:px-10">
          <div className="mx-auto flex max-w-[1320px] flex-col justify-between gap-7 sm:flex-row sm:items-center">
            <div><p className="eyebrow text-[#648e8c]">Está em dúvida?</p><h2 className="mt-3 font-display text-4xl">Eu posso filtrar as melhores possibilidades para você.</h2></div>
            <a href={whatsappLink(`Olá, Jorge! Quero conhecer oportunidades em ${region.name}.`)} onClick={() => track("whatsapp_click", { from: "city", city: region.name })} target="_blank" rel="noreferrer" className="inline-flex shrink-0 items-center gap-3 rounded-full bg-[#102f3d] px-6 py-4 text-sm text-white">Conversar sobre {region.name} <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></a>
          </div>
        </section>
      </main>
      <PortalFooter />
    </div>
  );
}

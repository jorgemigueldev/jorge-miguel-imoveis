/* Design: Maré Editorial — páginas de detalhe e contato tratam o visitante como uma conversa consultiva, com CTA contextual. */
import { Link, useParams } from "wouter";
import { toast } from "sonner";
import { ArrowUpRight, Check, MessageCircle, Share2 } from "lucide-react";
import { PortalFooter, PortalHeader } from "@/components/PortalChrome";
import { PropertyGallery } from "@/components/PropertyGallery";
import { PropertyGrid, PropertyGridSkeleton } from "@/components/PropertyCard";
import { LeadForm } from "@/components/LeadForm";
import { SmartImage } from "@/components/SmartImage";
import { useProperties } from "@/hooks/useProperties";
import { useSEO } from "@/hooks/useSEO";
import { assets } from "@/lib/assets";
import { CRECI, INSTAGRAM_URL, track, whatsappLink, WHATSAPP_DISPLAY } from "@/lib/contact";
import { formatPrice, getNeighborhood, isListed, isViewable, slugify, type Property } from "@/lib/properties";

const pill = "inline-flex items-center gap-3 rounded-full bg-[#102f3d] px-6 py-4 text-sm text-white transition hover:bg-[#214e5a]";

export function PropertyPage() {
  const { id } = useParams<{ id: string }>();
  const { properties, loading } = useProperties();
  const property = properties.find((item) => item.id === id && isViewable(item));

  const sold = property?.status === "vendido";
  const description = property?.description || (property ? `${property.type} em ${property.neighborhood}, ${property.city}.` : undefined);
  useSEO(property ? {
    title: `${property.title} — ${property.neighborhood}, ${property.city}`,
    description,
    image: property.image,
    noindex: false,
    jsonLd: {
      "@context": "https://schema.org",
      "@type": "RealEstateListing",
      name: property.title,
      description,
      url: `${window.location.origin}/imovel/${property.id}`,
      image: property.gallery?.length ? property.gallery : property.image,
      ...(property.price && !sold ? { offers: { "@type": "Offer", price: property.price, priceCurrency: "BRL", availability: "https://schema.org/InStock" } } : {}),
    },
  } : { title: "Imóvel", noindex: true });

  if (loading) return <Shell><section className="px-5 py-28 lg:px-10"><div className="mx-auto max-w-[1320px]"><PropertyGridSkeleton /></div></section></Shell>;
  if (!property) return <EmptyPage title="Este imóvel não está disponível." copy="Ele pode ter sido vendido ou ainda não foi publicado. Fale comigo e eu procuro uma seleção alinhada ao seu objetivo." />;

  const message = sold
    ? `Olá, Jorge. Vi que o imóvel ${property.id} — ${property.title} — foi vendido. Gostaria de ver opções parecidas.`
    : `Olá, Jorge. Vi o imóvel ${property.id} — ${property.title} — no seu site e gostaria de receber mais informações.`;
  const images = property.gallery?.length ? property.gallery : property.image ? [property.image] : [];
  const facts: [string, string | undefined][] = [
    ["Área", property.area ? `${property.area} m²` : undefined],
    ["Dormitórios", property.bedrooms ? String(property.bedrooms) : undefined],
    ["Suítes", property.suites ? String(property.suites) : undefined],
    ["Vagas", property.parking ? String(property.parking) : undefined],
    ["Construtora", property.developer],
    ["Entrega", property.delivery],
  ];
  const shown = facts.filter(([, value]) => value) as [string, string][];
  const related = properties.filter((p) => p.id !== property.id && isListed(p) && p.regionSlug === property.regionSlug).slice(0, 3);

  const share = async () => {
    const url = window.location.href;
    track("property_share", { id: property.id });
    try {
      if (navigator.share) await navigator.share({ title: property.title, url });
      else { await navigator.clipboard.writeText(url); toast.success("Link copiado"); }
    } catch { /* usuário cancelou o compartilhamento */ }
  };

  return (
    <Shell>
      <section className="bg-[#102f3d] px-5 py-20 text-white lg:px-10 lg:py-28">
        <div className="mx-auto max-w-[1320px]">
          <nav aria-label="Você está em" className="text-[11px] uppercase tracking-[0.16em] text-[#8ec8ba]"><Link href="/imoveis">Imóveis</Link> / <Link href={`/cidades/${property.regionSlug}`}>{property.city}</Link></nav>
          <p className="eyebrow mt-8 text-[#8ec8ba]">Código {property.id}</p>
          <h1 className="mt-5 max-w-4xl font-display text-6xl leading-[.9] sm:text-7xl">{property.title}</h1>
          <p className="mt-7 text-white/65">{property.neighborhood} · {property.type}</p>
        </div>
      </section>

      <section className="px-5 py-16 lg:px-10 lg:py-20">
        <div className="mx-auto grid max-w-[1320px] gap-12 lg:grid-cols-[1.2fr_.8fr]">
          <PropertyGallery images={images} title={property.title} />
          <div>
            {sold && <p className="mb-6 border-l-2 border-[#6caaa0] bg-[#edf0eb] p-4 text-sm text-[#46636c]">Este imóvel já foi vendido. Posso te mostrar opções parecidas.</p>}
            <p className="font-display text-5xl">{sold ? "Vendido" : formatPrice(property.price)}</p>
            <p className="eyebrow mt-8 text-[#648e8c]">Por que olhar este imóvel</p>
            <p className="mt-4 whitespace-pre-line text-lg leading-relaxed text-[#53707a]">{description}</p>
            {shown.length > 0 && <dl className="mt-8 grid grid-cols-2 gap-x-6 gap-y-5 border-t border-[#102f3d]/10 pt-6">{shown.map(([label, value]) => <div key={label}><dt className="text-[10px] uppercase tracking-[0.18em] text-[#648e8c]">{label}</dt><dd className="mt-1 text-[#102f3d]">{value}</dd></div>)}</dl>}
            {property.features?.length ? <ul className="mt-8 grid gap-3 border-t border-[#102f3d]/10 pt-6 text-sm text-[#46636c]">{property.features.map((feature) => <li key={feature} className="flex items-center gap-3"><Check className="h-4 w-4 shrink-0 text-[#6caaa0]" />{feature}</li>)}</ul> : null}
            <div className="mt-9 flex flex-wrap gap-3">
              <a href={whatsappLink(message)} onClick={() => track("whatsapp_click", { from: "property", id: property.id })} target="_blank" rel="noreferrer" className={pill}>{sold ? "Ver opções parecidas" : "Tenho interesse neste imóvel"} <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></a>
              <button type="button" onClick={share} className="inline-flex items-center gap-2 rounded-full border border-[#102f3d]/25 px-6 py-4 text-sm"><Share2 className="h-4 w-4" /> Compartilhar</button>
            </div>
          </div>
        </div>
      </section>

      {related.length > 0 && <section className="bg-[#e7e4db] px-5 py-16 lg:px-10"><div className="mx-auto max-w-[1320px]"><p className="eyebrow text-[#648e8c]">Continue explorando</p><h2 className="mb-8 mt-3 font-display text-4xl">Mais em {property.city}</h2><PropertyGrid properties={related} /></div></section>}
    </Shell>
  );
}

export function NeighborhoodPage() {
  const { city, neighborhood } = useParams<{ city: string; neighborhood: string }>();
  const found = getNeighborhood(city, neighborhood);
  const { properties, loading } = useProperties();
  useSEO(found ? { title: `Imóveis em ${found.name}, ${found.region.name}`, description: `Guia de ${found.name} em ${found.region.name}: estilo de vida, proximidade do mar e imóveis selecionados por Jorge Miguel.` } : { title: "Bairro", noindex: true });

  if (!found) return <EmptyPage title="Não encontramos este bairro." copy="Veja as regiões em que atuo ou fale comigo para uma busca personalizada." />;
  const { region, name } = found;
  const here = properties.filter((p) => isListed(p) && p.regionSlug === region.slug && slugify(p.neighborhood) === slugify(name));

  return (
    <Shell>
      <section className="bg-[#102f3d] px-5 py-24 text-white lg:px-10 lg:py-32">
        <div className="mx-auto max-w-[1320px]">
          <p className="eyebrow text-[#8ec8ba]"><Link href={`/cidades/${region.slug}`}>{region.name}</Link> · Guia de bairro</p>
          <h1 className="mt-5 font-display text-6xl leading-[.9] sm:text-7xl">{name}</h1>
          <p className="mt-7 max-w-xl text-lg leading-relaxed text-white/65">Estilo de vida, proximidade do mar e oportunidades selecionadas em {name}, {region.name}.</p>
        </div>
      </section>
      {(loading || here.length > 0) && <section className="px-5 pt-20 lg:px-10"><div className="mx-auto max-w-[1320px]"><h2 className="mb-8 font-display text-4xl">Imóveis em {name}</h2>{loading ? <PropertyGridSkeleton /> : <PropertyGrid properties={here} />}</div></section>}
      <section className="px-5 py-20 lg:px-10 lg:py-28">
        <div className="mx-auto grid max-w-[1320px] gap-14 lg:grid-cols-2">
          <div><p className="eyebrow text-[#648e8c]">Intenção de compra</p><h2 className="mt-4 font-display text-5xl">O que você procura neste bairro?</h2><p className="mt-6 text-base leading-relaxed text-[#53707a]">Escolha um objetivo e receba uma conversa mais direcionada, com imóveis e condições compatíveis com o seu momento.</p></div>
          <div className="grid gap-3">{["Morar perto do mar", "Investir na planta", "Comprar alto padrão", "Gerar renda com locação"].map((item) => <a key={item} href={whatsappLink(`Olá, Jorge! Quero ${item.toLowerCase()} em ${name}, ${region.name}.`)} onClick={() => track("whatsapp_click", { from: "neighborhood", neighborhood: name })} target="_blank" rel="noreferrer" className="flex items-center justify-between border-b border-[#102f3d]/15 py-5 text-lg text-[#46636c] hover:text-[#102f3d]"><span className="flex items-center gap-3"><Check className="h-4 w-4 text-[#6caaa0]" />{item}</span><ArrowUpRight className="h-4 w-4" /></a>)}</div>
        </div>
      </section>
    </Shell>
  );
}

export function AboutPage() {
  useSEO({ title: "Sobre Jorge Miguel", description: `Jorge Miguel, corretor de imóveis (${CRECI}) com atuação em Barra Velha, Balneário Piçarras e Penha.` });
  return (
    <Shell>
      <section className="bg-[#e7e4db] px-5 py-24 lg:px-10 lg:py-32">
        <div className="mx-auto grid max-w-[1320px] gap-12 lg:grid-cols-2 lg:items-center">
          <SmartImage src={assets.portrait} alt="Jorge Miguel, corretor de imóveis" className="aspect-[4/5] max-h-[620px] w-full object-cover" />
          <div>
            <p className="eyebrow text-[#648e8c]">Jorge Miguel Imóveis · {CRECI}</p>
            <h1 className="mt-5 font-display text-6xl leading-[.9] sm:text-7xl">Curadoria para viver e investir melhor.</h1>
            <p className="mt-8 text-lg leading-relaxed text-[#53707a]">Mais de 5 anos de experiência no mercado imobiliário, com atuação próxima em Barra Velha, Balneário Piçarras e Penha.</p>
            <a href={whatsappLink("Olá, Jorge! Quero conhecer seu atendimento.")} onClick={() => track("whatsapp_click", { from: "about" })} target="_blank" rel="noreferrer" className={`mt-9 ${pill}`}>Falar com Jorge <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></a>
          </div>
        </div>
      </section>
    </Shell>
  );
}

export function ContactPage() {
  useSEO({ title: "Contato", description: "Fale com Jorge Miguel pelo WhatsApp e receba uma seleção de imóveis no Litoral Norte de SC." });
  return (
    <Shell>
      <section className="px-5 py-24 lg:px-10 lg:py-32">
        <div className="mx-auto grid max-w-[1320px] gap-14 lg:grid-cols-[.8fr_1.2fr]">
          <div>
            <p className="eyebrow text-[#648e8c]">Atendimento consultivo</p>
            <h1 className="mt-5 font-display text-6xl leading-[.9] sm:text-7xl">Vamos encontrar o caminho certo?</h1>
            <p className="mt-7 max-w-lg text-lg leading-relaxed text-[#53707a]">Conte o que você busca. O WhatsApp abrirá com o contexto para que a conversa comece melhor.</p>
            <div className="mt-10 border border-[#102f3d]/10 bg-white p-8">
              <p className="eyebrow text-[#648e8c]">Contato direto</p>
              <a href={whatsappLink("Olá, Jorge! Quero conversar sobre um imóvel.")} onClick={() => track("whatsapp_click", { from: "contact" })} target="_blank" rel="noreferrer" className="mt-7 flex items-center justify-between border-b border-[#102f3d]/10 py-5 text-lg">WhatsApp · {WHATSAPP_DISPLAY} <MessageCircle className="h-5 w-5 text-[#6caaa0]" /></a>
              <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="flex items-center justify-between border-b border-[#102f3d]/10 py-5 text-lg">Instagram <ArrowUpRight className="h-5 w-5 text-[#6caaa0]" /></a>
              <p className="mt-8 text-sm leading-relaxed text-[#648e8c]">Barra Velha · Balneário Piçarras · Penha<br />{CRECI}</p>
            </div>
          </div>
          <div className="bg-[#102f3d]"><LeadForm source="contato" /></div>
        </div>
      </section>
    </Shell>
  );
}

export function PrivacyPage() {
  useSEO({ title: "Política de privacidade", description: "Como o site Jorge Miguel Imóveis trata dados pessoais." });
  const h2 = "mt-10 font-display text-3xl";
  return (
    <Shell>
      <section className="px-5 py-24 lg:px-10">
        <div className="mx-auto max-w-3xl text-[#46636c]">
          <p className="eyebrow text-[#648e8c]">Jorge Miguel Imóveis · {CRECI}</p>
          <h1 className="mt-5 font-display text-6xl leading-[.92] text-[#102f3d]">Política de privacidade</h1>
          <p className="mt-4 text-sm text-[#648e8c]">Atualizada em 14/10/2026.</p>
          <h2 className={h2}>Quais dados o site coleta</h2>
          <p className="mt-3 leading-relaxed">Os formulários do site pedem nome, WhatsApp, objetivo, região e faixa de investimento apenas para montar uma mensagem que você envia a Jorge Miguel pelo WhatsApp. O site não armazena essas informações em banco de dados próprio.</p>
          <h2 className={h2}>Como os dados são usados</h2>
          <p className="mt-3 leading-relaxed">Quando você envia a mensagem, os dados passam a ser usados para atendimento comercial: responder, enviar imóveis compatíveis e agendar conversas ou visitas. Esse envio acontece pelo WhatsApp, que possui sua própria política de privacidade.</p>
          <h2 className={h2}>Métricas e terceiros</h2>
          <p className="mt-3 leading-relaxed">O site pode usar uma ferramenta de métricas de audiência (Umami) para contar visitas e cliques em botões, sem identificar você pelo nome. Vídeos incorporados do YouTube e fontes do Google Fonts são carregados de servidores do Google. Se forem adotados pixels de anúncios (por exemplo Meta ou Google Ads), esta política será atualizada.</p>
          <h2 className={h2}>Seus direitos</h2>
          <p className="mt-3 leading-relaxed">Conforme a LGPD (Lei 13.709/2018), você pode pedir acesso, correção ou exclusão dos dados que tenha enviado, e deixar de receber contatos, a qualquer momento pelo WhatsApp {WHATSAPP_DISPLAY}.</p>
        </div>
      </section>
    </Shell>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-[#f7f5ef] text-[#102f3d]"><PortalHeader /><main id="conteudo">{children}</main><PortalFooter /></div>;
}

export function EmptyPage({ title, copy }: { title: string; copy: string }) {
  return (
    <Shell>
      <section className="px-5 py-28 lg:px-10">
        <div className="mx-auto max-w-3xl">
          <p className="eyebrow text-[#648e8c]">Jorge Miguel Imóveis</p>
          <h1 className="mt-5 font-display text-6xl leading-[.92]">{title}</h1>
          <p className="mt-7 text-lg leading-relaxed text-[#53707a]">{copy}</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/imoveis" className={pill}>Ver imóveis <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></Link>
            <a href={whatsappLink()} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-[#102f3d]/25 px-6 py-4 text-sm">Falar com Jorge</a>
          </div>
        </div>
      </section>
    </Shell>
  );
}

import { Link } from "wouter";
import { ArrowUpRight } from "lucide-react";
import { PortalFooter, PortalHeader } from "@/components/PortalChrome";
import { SmartImage } from "@/components/SmartImage";
import { useSEO } from "@/hooks/useSEO";
import { regions } from "@/lib/properties";

export default function CityIndex() {
  useSEO({ title: "Regiões de atuação", description: "Balneário Piçarras, Penha e Barra Velha: conheça os bairros e as oportunidades de cada região do Litoral Norte de SC." });
  return (
    <div className="min-h-screen bg-[#f7f5ef] text-[#102f3d]">
      <PortalHeader />
      <main id="conteudo" className="mx-auto max-w-[1320px] px-5 py-16 lg:px-10">
        <p className="eyebrow text-[#648e8c]">Jorge Miguel Imóveis</p>
        <h1 className="mt-6 font-display text-6xl leading-[.9] sm:text-7xl">Escolha uma região.</h1>
        <p className="mt-6 max-w-xl text-lg text-[#53707a]">Conheça os recortes de atuação e encontre o ponto de partida para a sua busca.</p>
        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {regions.map((region) => (
            <Link key={region.slug} href={`/cidades/${region.slug}`} className="group relative min-h-[380px] overflow-hidden bg-[#102f3d]">
              <SmartImage src={region.image} alt="" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b2935] via-[#0b2935]/30 to-transparent" />
              <div className="relative flex h-full min-h-[380px] flex-col justify-end p-7 text-white">
                <p className="text-xs uppercase tracking-[0.2em] text-[#b9ddd4]">{region.kicker}</p>
                <h2 className="mt-2 flex items-center justify-between font-display text-4xl">{region.name} <ArrowUpRight className="h-6 w-6 text-[#8ec8ba]" /></h2>
              </div>
            </Link>
          ))}
        </div>
      </main>
      <PortalFooter />
    </div>
  );
}

/* Design: Maré Editorial — catálogo com filtros consultivos, URL compartilhável e estados honestos (carregando, erro, vazio). */
import { useMemo } from "react";
import { useSearchParams } from "wouter";
import { ArrowUpRight, ChevronDown, Search, Sparkles, X } from "lucide-react";
import { PortalFooter, PortalHeader } from "@/components/PortalChrome";
import { PropertyGrid, PropertyGridSkeleton } from "@/components/PropertyCard";
import { useProperties } from "@/hooks/useProperties";
import { useSEO } from "@/hooks/useSEO";
import { track, whatsappLink } from "@/lib/contact";
import { ALL_BUDGETS, ALL_PURPOSES, ALL_REGIONS, budgetRanges, defaultFilters, filterProperties, getRegion, purposes, regions, sortOptions, type Filters, type SortValue } from "@/lib/properties";

/* Estado dos filtros vive na URL: /imoveis?cidade=penha&finalidade=Investir — dá para compartilhar e usar em anúncios. */
function useFilters() {
  const [params, setParams] = useSearchParams();
  const sort = params.get("ordem") as SortValue | null;
  const filters: Filters = {
    query: params.get("q") ?? "",
    region: getRegion(params.get("cidade") ?? "")?.name ?? ALL_REGIONS,
    purpose: params.get("finalidade") ?? ALL_PURPOSES,
    budget: params.get("faixa") ?? ALL_BUDGETS,
    sort: sortOptions.some((o) => o.value === sort) ? (sort as SortValue) : defaultFilters.sort,
  };
  const set = (patch: Partial<Filters>) => {
    const next = { ...filters, ...patch };
    const entries: [string, string][] = [
      ["q", next.query],
      ["cidade", regions.find((r) => r.name === next.region)?.slug ?? ""],
      ["finalidade", next.purpose === ALL_PURPOSES ? "" : next.purpose],
      ["faixa", next.budget === ALL_BUDGETS ? "" : next.budget],
      ["ordem", next.sort === defaultFilters.sort ? "" : next.sort],
    ];
    setParams(new URLSearchParams(entries.filter(([, v]) => v)), { replace: true });
  };
  const hasFilters = !!filters.query || filters.region !== ALL_REGIONS || filters.purpose !== ALL_PURPOSES || filters.budget !== ALL_BUDGETS;
  return { filters, set, clear: () => setParams(new URLSearchParams(), { replace: true }), hasFilters };
}

export default function Catalog() {
  useSEO({ title: "Imóveis no Litoral Norte de SC", description: "Imóveis selecionados em Balneário Piçarras, Penha e Barra Velha: filtre por cidade, finalidade e faixa de investimento." });
  const { properties, loading, error } = useProperties();
  const { filters, set, clear, hasFilters } = useFilters();
  const filtered = useMemo(() => filterProperties(properties, filters), [properties, filters]);
  const hasCatalog = properties.some((p) => p.authorized && p.status !== "rascunho" && p.status !== "vendido");

  return (
    <div className="min-h-screen bg-[#f7f5ef] text-[#102f3d]">
      <PortalHeader />
      <main id="conteudo">
        <section className="bg-[#102f3d] px-5 py-20 text-white lg:px-10 lg:py-28">
          <div className="mx-auto max-w-[1320px]">
            <p className="eyebrow text-[#8ec8ba]">Mapa de oportunidades</p>
            <h1 className="mt-5 max-w-3xl font-display text-6xl leading-[.92] sm:text-7xl">Encontre o imóvel certo para o seu próximo capítulo.</h1>
            <p className="mt-7 max-w-xl text-base leading-relaxed text-white/65">Pesquise por localização, finalidade e faixa de investimento. Cada imóvel é selecionado e apresentado com contexto.</p>
          </div>
        </section>

        <section className="-mt-10 px-5 pb-24 lg:px-10">
          <div className="mx-auto max-w-[1320px]">
            <div role="search" className="grid gap-3 border border-[#102f3d]/10 bg-[#f7f5ef] p-4 shadow-xl shadow-[#102f3d]/5 md:grid-cols-2 lg:grid-cols-5">
              <label className="relative flex items-center gap-3 border-b border-[#102f3d]/15 px-3 py-3 lg:col-span-2 lg:border-b-0 lg:border-r">
                <Search className="h-4 w-4 text-[#6caaa0]" aria-hidden />
                <input type="search" value={filters.query} onChange={(e) => set({ query: e.target.value })} placeholder="Cidade, bairro, tipo ou construtora" aria-label="Buscar imóveis" className="w-full bg-transparent text-sm outline-none placeholder:text-[#648e8c]" />
              </label>
              <FilterSelect label="Região" value={filters.region} onChange={(region) => set({ region })} options={[ALL_REGIONS, ...regions.map((r) => r.name)]} />
              <FilterSelect label="Finalidade" value={filters.purpose} onChange={(purpose) => set({ purpose })} options={[ALL_PURPOSES, ...purposes]} />
              <FilterSelect label="Faixa de investimento" value={filters.budget} onChange={(budget) => set({ budget })} options={[ALL_BUDGETS, ...budgetRanges.map((r) => r.label)]} />
            </div>

            <div className="mt-16 flex flex-col justify-between gap-5 border-b border-[#102f3d]/10 pb-6 sm:flex-row sm:items-end">
              <div>
                <p className="eyebrow text-[#648e8c]">{hasCatalog ? "Curadoria atual" : "Curadoria em atualização"}</p>
                <h2 className="mt-3 font-display text-5xl">Imóveis selecionados</h2>
              </div>
              <div className="flex flex-wrap items-center gap-5 text-sm text-[#648e8c]">
                <span aria-live="polite">{filtered.length} {filtered.length === 1 ? "resultado" : "resultados"}</span>
                {hasFilters && <button type="button" onClick={clear} className="flex items-center gap-1 text-[#102f3d] underline-offset-4 hover:underline"><X className="h-3.5 w-3.5" /> Limpar filtros</button>}
                {hasCatalog && <label className="flex items-center gap-2">Ordenar<select value={filters.sort} onChange={(e) => set({ sort: e.target.value as SortValue })} className="border-b border-[#102f3d]/20 bg-transparent py-1 text-[#102f3d] outline-none">{sortOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select></label>}
              </div>
            </div>

            <div className="mt-8">
              {loading ? <PropertyGridSkeleton /> : error ? (
                <Notice title="Não foi possível carregar os imóveis agora." copy="Atualize a página em instantes ou fale comigo: eu envio a seleção direto no WhatsApp." />
              ) : filtered.length ? <PropertyGrid properties={filtered} /> : hasCatalog && hasFilters ? (
                <Notice title="Nenhum imóvel com esses filtros." copy="Tente ampliar a faixa de investimento ou a região. Também posso buscar oportunidades que ainda não estão publicadas." action={<button type="button" onClick={clear} className="rounded-full border border-[#102f3d]/25 px-6 py-4 text-sm">Limpar filtros</button>} />
              ) : (
                <EmptyCatalog />
              )}
            </div>
          </div>
        </section>
      </main>
      <PortalFooter />
    </div>
  );
}

function Notice({ title, copy, action }: { title: string; copy: string; action?: React.ReactNode }) {
  return (
    <div className="border border-dashed border-[#102f3d]/20 bg-[#edf0eb] p-8 lg:p-12">
      <h3 className="max-w-xl font-display text-4xl leading-[.98]">{title}</h3>
      <p className="mt-4 max-w-lg text-[#53707a]">{copy}</p>
      <div className="mt-7 flex flex-wrap gap-3">
        {action}
        <a href={whatsappLink("Olá, Jorge! Quero receber uma seleção de imóveis.")} onClick={() => track("whatsapp_click", { from: "catalog_notice" })} target="_blank" rel="noreferrer" className="inline-flex items-center gap-3 rounded-full bg-[#102f3d] px-6 py-4 text-sm text-white">Falar com Jorge <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></a>
      </div>
    </div>
  );
}

function EmptyCatalog() {
  return (
    <div className="grid gap-10 border border-dashed border-[#102f3d]/20 bg-[#edf0eb] p-8 lg:grid-cols-[1fr_.8fr] lg:p-14">
      <div>
        <Sparkles className="h-8 w-8 text-[#6caaa0]" />
        <h3 className="mt-7 max-w-xl font-display text-5xl leading-[.95]">Sua próxima oportunidade entra aqui.</h3>
        <p className="mt-5 max-w-lg text-base leading-relaxed text-[#53707a]">Estou atualizando a vitrine. Enquanto isso, conte o que você procura e receba uma seleção personalizada diretamente no WhatsApp.</p>
        <a href={whatsappLink("Olá, Jorge! Quero receber uma seleção de imóveis.")} onClick={() => track("whatsapp_click", { from: "catalog_empty" })} target="_blank" rel="noreferrer" className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#102f3d] px-6 py-4 text-sm text-white">Falar com Jorge <ArrowUpRight className="h-4 w-4 text-[#8ec8ba]" /></a>
      </div>
      <div className="grid content-start gap-3">
        <p className="eyebrow text-[#648e8c]">O que você poderá filtrar</p>
        {["Cidade e bairro", "Morar, investir, alto padrão ou renda", "Faixa de investimento", "Imóveis na planta e lançamentos"].map((item) => <div key={item} className="flex items-center gap-3 border-b border-[#102f3d]/10 py-4 text-sm text-[#46636c]"><span className="h-2 w-2 rounded-full bg-[#8ec8ba]" />{item}</div>)}
      </div>
    </div>
  );
}

function FilterSelect({ label, value, onChange, options }: { label: string; value: string; onChange: (value: string) => void; options: string[] }) {
  return (
    <label className="relative flex items-center border-b border-[#102f3d]/15 px-3 py-3 lg:border-b-0 lg:border-r">
      <select aria-label={label} value={value} onChange={(e) => onChange(e.target.value)} className="w-full appearance-none bg-transparent pr-5 text-xs text-[#46636c] outline-none">{options.map((option) => <option key={option}>{option}</option>)}</select>
      <ChevronDown className="pointer-events-none absolute right-3 h-4 w-4 text-[#6caaa0]" aria-hidden />
    </label>
  );
}

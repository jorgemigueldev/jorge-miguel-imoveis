# Direção de design — Jorge Miguel Imóveis

## Abordagens consideradas

### 1. Maré Editorial
Uma estética costeira sofisticada, com fotografia ampla, areia clara, azul profundo e tipografia editorial. A marca deve transmitir curadoria, confiança e patrimônio sem parecer um portal imobiliário genérico.
**Probabilidade:** 0,07

### 2. Riviera Solar
Uma direção luminosa e mediterrânea, com cores claras, terracota, verde-oliva e composição mais descontraída. Evoca férias e estilo de vida, mas pode reduzir a percepção de exclusividade.
**Probabilidade:** 0,04

### 3. Atlântico Noturno
Uma estética escura, cinematográfica e contrastada, com navy, cobre e imagens noturnas de empreendimentos. Tem força para alto padrão, mas pode ficar distante do acolhimento praiano desejado.
**Probabilidade:** 0,02

## Abordagem escolhida: Maré Editorial

### Design Movement
Editorial costeiro contemporâneo, inspirado em revistas de arquitetura, hotéis boutique e catálogos de patrimônio à beira-mar.

### Core Principles
- Curadoria antes de volume: mostrar que Jorge seleciona oportunidades, não apenas lista imóveis.
- Litoral como ativo de vida e patrimônio: cada bloco conecta localização, objetivo e decisão.
- Luxo silencioso: espaços amplos, contrastes precisos e detalhes refinados sem excesso ornamental.
- Conversão natural: CTAs aparecem como convites consultivos, nunca como pressão comercial.

### Color Philosophy
Azul-marinho profundo cria confiança e autoridade; areia quente aproxima a experiência do litoral; branco concha preserva leveza; verde-água funciona como assinatura viva e moderna. A paleta evita o azul corporativo comum e trata a marca como uma curadoria costeira premium.

### Layout Paradigm
Composição editorial assimétrica: hero dividido entre texto e imagem, cards de regiões em mosaico, faixas horizontais de dados e seções com alinhamentos alternados. O conteúdo respira e evita o padrão de blocos centralizados repetitivos.

### Signature Elements
- Linha de horizonte fina em verde-água acompanhando títulos e divisores.
- Etiquetas de localização com coordenadas visuais e pequenos marcadores circulares.
- Cartões de oportunidade com borda areia, sombra baixa e microcopy de curadoria.

### Interaction Philosophy
Cada interação deve parecer uma conversa inicial com um consultor: o visitante escolhe objetivo, região e faixa de investimento, e recebe uma ação clara para conversar no WhatsApp. Hover e foco revelam contexto adicional sem esconder informação essencial.

### Animation
Entradas discretas por opacidade e deslocamento vertical curto, com stagger de 50ms nas opções de intenção. Imagens ampliam 1.03x no hover; botões respondem com scale 0.97 no clique. Todas as animações respeitam prefers-reduced-motion.

### Typography System
Display: Cormorant Garamond, com contraste editorial para títulos e números de destaque. Interface e corpo: DM Sans, para legibilidade, precisão e aparência contemporânea. Títulos usam peso 500–600; labels em caixa alta com tracking amplo; texto corrido em 16–18px.

### Brand Essence
Curadoria imobiliária premium para quem quer morar, investir ou construir patrimônio no Litoral Norte de Santa Catarina — com leitura local e atendimento próximo.
**Personalidade:** criteriosa, acolhedora, visionária.

### Brand Voice
Headlines são confiantes e sensoriais; CTAs são diretos, mas consultivos; microcopy reduz ansiedade e explica o próximo passo.
- “Você não precisa conhecer todos os imóveis. Precisa conhecer os certos.”
- “Conte o que você busca. Eu seleciono o que faz sentido para o seu momento.”

### Wordmark & Logo
Wordmark em caixa alta com espaçamento generoso, acompanhado por um símbolo abstrato de onda e horizonte. O símbolo deve funcionar sozinho em avatar e favicon, sem depender de iniciais.

### Signature Brand Color
Verde-maré #79B9AF — um teal dessaturado, próprio e memorável, que conecta mar, confiança e sofisticação.

## Regras de implementação
A landing page terá uma única rota principal, navegação âncora, foco em WhatsApp, formulário de qualificação local e dados demonstrativos claramente tratados como curadoria inicial. Não serão inventados depoimentos, avaliações ou fotos de imóveis específicos. Conteúdo e imagens de terceiros só entram mediante autorização; os ativos visuais principais serão próprios e gerados para a marca.
